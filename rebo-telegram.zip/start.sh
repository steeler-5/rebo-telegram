#!/bin/bash
python telegram_poller.py